package com.example.kc_kape_mo

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
