# Kc Kape Mo
Mock Firebase/Auth and GCash integrated app.